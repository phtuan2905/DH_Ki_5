﻿namespace LTTQ_C6_BT6_5.DanhMuc
{
    partial class FormHoaDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_khachhang = new System.Windows.Forms.Button();
            this.comboBox_makhachhang = new System.Windows.Forms.ComboBox();
            this.textBox_dienthoai = new System.Windows.Forms.TextBox();
            this.textBox_diachi = new System.Windows.Forms.TextBox();
            this.textBox_tenkhachhang = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox_manhanvien = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_ngayban = new System.Windows.Forms.DateTimePicker();
            this.textBox_tennhanvien = new System.Windows.Forms.TextBox();
            this.textBox_mahoadon = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_themhoadon = new System.Windows.Forms.Button();
            this.button_luu = new System.Windows.Forms.Button();
            this.button_huyhoadon = new System.Windows.Forms.Button();
            this.button_inhoadon = new System.Windows.Forms.Button();
            this.button_dong = new System.Windows.Forms.Button();
            this.textBox_tongtien = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label_tiendangchu = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_thanhtien = new System.Windows.Forms.TextBox();
            this.textBox_dongia = new System.Windows.Forms.TextBox();
            this.textBox_giamgia = new System.Windows.Forms.TextBox();
            this.textBox_tenhang = new System.Windows.Forms.TextBox();
            this.textBox_soluong = new System.Windows.Forms.TextBox();
            this.comboBox_mahang = new System.Windows.Forms.ComboBox();
            this.dataGridView_hoadon = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox_mahoadon = new System.Windows.Forms.ComboBox();
            this.button_timkiem = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hoadon)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 50);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(356, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(343, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "HÓA ĐƠN BÁN HÀNG";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Location = new System.Drawing.Point(16, 60);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1035, 177);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin chung";
            // 
            // panel3
            // 
            this.panel3.AutoSize = true;
            this.panel3.Controls.Add(this.button_khachhang);
            this.panel3.Controls.Add(this.comboBox_makhachhang);
            this.panel3.Controls.Add(this.textBox_dienthoai);
            this.panel3.Controls.Add(this.textBox_diachi);
            this.panel3.Controls.Add(this.textBox_tenkhachhang);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(500, 19);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(496, 154);
            this.panel3.TabIndex = 4;
            // 
            // button_khachhang
            // 
            this.button_khachhang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_khachhang.Location = new System.Drawing.Point(392, 5);
            this.button_khachhang.Margin = new System.Windows.Forms.Padding(4);
            this.button_khachhang.Name = "button_khachhang";
            this.button_khachhang.Size = new System.Drawing.Size(100, 28);
            this.button_khachhang.TabIndex = 42;
            this.button_khachhang.Text = "Khách hàng";
            this.button_khachhang.UseVisualStyleBackColor = true;
            this.button_khachhang.Click += new System.EventHandler(this.button_khachhang_Click);
            // 
            // comboBox_makhachhang
            // 
            this.comboBox_makhachhang.FormattingEnabled = true;
            this.comboBox_makhachhang.Location = new System.Drawing.Point(144, 6);
            this.comboBox_makhachhang.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_makhachhang.Name = "comboBox_makhachhang";
            this.comboBox_makhachhang.Size = new System.Drawing.Size(240, 24);
            this.comboBox_makhachhang.TabIndex = 9;
            this.comboBox_makhachhang.SelectedIndexChanged += new System.EventHandler(this.comboBox_makhachhang_SelectedIndexChanged);
            // 
            // textBox_dienthoai
            // 
            this.textBox_dienthoai.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_dienthoai.Location = new System.Drawing.Point(144, 105);
            this.textBox_dienthoai.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_dienthoai.Name = "textBox_dienthoai";
            this.textBox_dienthoai.Size = new System.Drawing.Size(348, 22);
            this.textBox_dienthoai.TabIndex = 8;
            this.textBox_dienthoai.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_dienthoai_KeyDown);
            this.textBox_dienthoai.Leave += new System.EventHandler(this.textBox_dienthoai_Leave);
            // 
            // textBox_diachi
            // 
            this.textBox_diachi.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_diachi.Location = new System.Drawing.Point(144, 73);
            this.textBox_diachi.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_diachi.Name = "textBox_diachi";
            this.textBox_diachi.ReadOnly = true;
            this.textBox_diachi.Size = new System.Drawing.Size(348, 22);
            this.textBox_diachi.TabIndex = 7;
            // 
            // textBox_tenkhachhang
            // 
            this.textBox_tenkhachhang.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_tenkhachhang.Location = new System.Drawing.Point(144, 41);
            this.textBox_tenkhachhang.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_tenkhachhang.Name = "textBox_tenkhachhang";
            this.textBox_tenkhachhang.ReadOnly = true;
            this.textBox_tenkhachhang.Size = new System.Drawing.Size(348, 22);
            this.textBox_tenkhachhang.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 78);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Địa chỉ:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 10);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Mã khách hàng: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 44);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Tên khách hàng: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 111);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 16);
            this.label9.TabIndex = 3;
            this.label9.Text = "Điện thoại:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.comboBox_manhanvien);
            this.panel2.Controls.Add(this.dateTimePicker_ngayban);
            this.panel2.Controls.Add(this.textBox_tennhanvien);
            this.panel2.Controls.Add(this.textBox_mahoadon);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(4, 19);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(496, 154);
            this.panel2.TabIndex = 0;
            // 
            // comboBox_manhanvien
            // 
            this.comboBox_manhanvien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_manhanvien.BackColor = System.Drawing.SystemColors.Info;
            this.comboBox_manhanvien.Enabled = false;
            this.comboBox_manhanvien.FormattingEnabled = true;
            this.comboBox_manhanvien.Location = new System.Drawing.Point(127, 71);
            this.comboBox_manhanvien.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_manhanvien.Name = "comboBox_manhanvien";
            this.comboBox_manhanvien.Size = new System.Drawing.Size(348, 24);
            this.comboBox_manhanvien.TabIndex = 10;
            this.comboBox_manhanvien.SelectedIndexChanged += new System.EventHandler(this.comboBox_manhanvien_SelectedIndexChanged);
            // 
            // dateTimePicker_ngayban
            // 
            this.dateTimePicker_ngayban.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker_ngayban.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker_ngayban.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_ngayban.Location = new System.Drawing.Point(127, 41);
            this.dateTimePicker_ngayban.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker_ngayban.Name = "dateTimePicker_ngayban";
            this.dateTimePicker_ngayban.Size = new System.Drawing.Size(348, 22);
            this.dateTimePicker_ngayban.TabIndex = 6;
            // 
            // textBox_tennhanvien
            // 
            this.textBox_tennhanvien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_tennhanvien.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_tennhanvien.Location = new System.Drawing.Point(127, 107);
            this.textBox_tennhanvien.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_tennhanvien.Name = "textBox_tennhanvien";
            this.textBox_tennhanvien.ReadOnly = true;
            this.textBox_tennhanvien.Size = new System.Drawing.Size(348, 22);
            this.textBox_tennhanvien.TabIndex = 5;
            // 
            // textBox_mahoadon
            // 
            this.textBox_mahoadon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_mahoadon.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_mahoadon.Location = new System.Drawing.Point(127, 10);
            this.textBox_mahoadon.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_mahoadon.Name = "textBox_mahoadon";
            this.textBox_mahoadon.ReadOnly = true;
            this.textBox_mahoadon.Size = new System.Drawing.Size(348, 22);
            this.textBox_mahoadon.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 78);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Mã nhân viên: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 10);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã hóa đơn: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 44);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Ngày bán: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 111);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "Tên nhân viên: ";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Controls.Add(this.textBox_thanhtien);
            this.groupBox2.Controls.Add(this.textBox_dongia);
            this.groupBox2.Controls.Add(this.textBox_giamgia);
            this.groupBox2.Controls.Add(this.textBox_tenhang);
            this.groupBox2.Controls.Add(this.textBox_soluong);
            this.groupBox2.Controls.Add(this.comboBox_mahang);
            this.groupBox2.Controls.Add(this.dataGridView_hoadon);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(16, 245);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1035, 374);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin các mặt hàng";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.button_themhoadon);
            this.panel4.Controls.Add(this.button_luu);
            this.panel4.Controls.Add(this.button_huyhoadon);
            this.panel4.Controls.Add(this.button_inhoadon);
            this.panel4.Controls.Add(this.button_dong);
            this.panel4.Controls.Add(this.textBox_tongtien);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label_tiendangchu);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Location = new System.Drawing.Point(31, 270);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(967, 97);
            this.panel4.TabIndex = 22;
            // 
            // button_themhoadon
            // 
            this.button_themhoadon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_themhoadon.Location = new System.Drawing.Point(316, 69);
            this.button_themhoadon.Margin = new System.Windows.Forms.Padding(4);
            this.button_themhoadon.Name = "button_themhoadon";
            this.button_themhoadon.Size = new System.Drawing.Size(133, 28);
            this.button_themhoadon.TabIndex = 41;
            this.button_themhoadon.Text = "Thêm hóa đơn";
            this.button_themhoadon.UseVisualStyleBackColor = true;
            this.button_themhoadon.Click += new System.EventHandler(this.button_themhoadon_Click);
            // 
            // button_luu
            // 
            this.button_luu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_luu.Location = new System.Drawing.Point(469, 69);
            this.button_luu.Margin = new System.Windows.Forms.Padding(4);
            this.button_luu.Name = "button_luu";
            this.button_luu.Size = new System.Drawing.Size(100, 28);
            this.button_luu.TabIndex = 40;
            this.button_luu.Text = "Lưu";
            this.button_luu.UseVisualStyleBackColor = true;
            this.button_luu.Click += new System.EventHandler(this.button_luu_Click);
            // 
            // button_huyhoadon
            // 
            this.button_huyhoadon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_huyhoadon.Location = new System.Drawing.Point(591, 69);
            this.button_huyhoadon.Margin = new System.Windows.Forms.Padding(4);
            this.button_huyhoadon.Name = "button_huyhoadon";
            this.button_huyhoadon.Size = new System.Drawing.Size(123, 28);
            this.button_huyhoadon.TabIndex = 39;
            this.button_huyhoadon.Text = "Hủy hóa đơn";
            this.button_huyhoadon.UseVisualStyleBackColor = true;
            this.button_huyhoadon.Click += new System.EventHandler(this.button_huyhoadon_Click);
            // 
            // button_inhoadon
            // 
            this.button_inhoadon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_inhoadon.Location = new System.Drawing.Point(743, 69);
            this.button_inhoadon.Margin = new System.Windows.Forms.Padding(4);
            this.button_inhoadon.Name = "button_inhoadon";
            this.button_inhoadon.Size = new System.Drawing.Size(100, 28);
            this.button_inhoadon.TabIndex = 38;
            this.button_inhoadon.Text = "In hóa đơn";
            this.button_inhoadon.UseVisualStyleBackColor = true;
            this.button_inhoadon.Click += new System.EventHandler(this.button_inhoadon_Click);
            // 
            // button_dong
            // 
            this.button_dong.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_dong.Location = new System.Drawing.Point(867, 69);
            this.button_dong.Margin = new System.Windows.Forms.Padding(4);
            this.button_dong.Name = "button_dong";
            this.button_dong.Size = new System.Drawing.Size(100, 28);
            this.button_dong.TabIndex = 37;
            this.button_dong.Text = "Đóng";
            this.button_dong.UseVisualStyleBackColor = true;
            // 
            // textBox_tongtien
            // 
            this.textBox_tongtien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_tongtien.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_tongtien.Location = new System.Drawing.Point(699, -1);
            this.textBox_tongtien.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_tongtien.Name = "textBox_tongtien";
            this.textBox_tongtien.ReadOnly = true;
            this.textBox_tongtien.Size = new System.Drawing.Size(267, 22);
            this.textBox_tongtien.TabIndex = 36;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label18.Location = new System.Drawing.Point(617, 2);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 16);
            this.label18.TabIndex = 35;
            this.label18.Text = "Tổng tiền:";
            // 
            // label_tiendangchu
            // 
            this.label_tiendangchu.AutoSize = true;
            this.label_tiendangchu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label_tiendangchu.Location = new System.Drawing.Point(69, 32);
            this.label_tiendangchu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_tiendangchu.Name = "label_tiendangchu";
            this.label_tiendangchu.Size = new System.Drawing.Size(92, 16);
            this.label_tiendangchu.TabIndex = 34;
            this.label_tiendangchu.Text = "Tiền dạng chữ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label17.Location = new System.Drawing.Point(0, 32);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 16);
            this.label17.TabIndex = 33;
            this.label17.Text = "Bằng chữ: ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(0, 2);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(161, 16);
            this.label16.TabIndex = 32;
            this.label16.Text = "Kích đúp một dòng để xóa";
            // 
            // textBox_thanhtien
            // 
            this.textBox_thanhtien.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_thanhtien.Location = new System.Drawing.Point(729, 62);
            this.textBox_thanhtien.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_thanhtien.Name = "textBox_thanhtien";
            this.textBox_thanhtien.ReadOnly = true;
            this.textBox_thanhtien.Size = new System.Drawing.Size(267, 22);
            this.textBox_thanhtien.TabIndex = 21;
            // 
            // textBox_dongia
            // 
            this.textBox_dongia.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_dongia.Location = new System.Drawing.Point(729, 30);
            this.textBox_dongia.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_dongia.Name = "textBox_dongia";
            this.textBox_dongia.ReadOnly = true;
            this.textBox_dongia.Size = new System.Drawing.Size(267, 22);
            this.textBox_dongia.TabIndex = 20;
            // 
            // textBox_giamgia
            // 
            this.textBox_giamgia.Location = new System.Drawing.Point(368, 62);
            this.textBox_giamgia.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_giamgia.Name = "textBox_giamgia";
            this.textBox_giamgia.Size = new System.Drawing.Size(263, 22);
            this.textBox_giamgia.TabIndex = 19;
            this.textBox_giamgia.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_giamgia_KeyDown);
            this.textBox_giamgia.Leave += new System.EventHandler(this.textBox_giamgia_Leave);
            // 
            // textBox_tenhang
            // 
            this.textBox_tenhang.BackColor = System.Drawing.SystemColors.Info;
            this.textBox_tenhang.Location = new System.Drawing.Point(368, 30);
            this.textBox_tenhang.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_tenhang.Name = "textBox_tenhang";
            this.textBox_tenhang.ReadOnly = true;
            this.textBox_tenhang.Size = new System.Drawing.Size(263, 22);
            this.textBox_tenhang.TabIndex = 18;
            // 
            // textBox_soluong
            // 
            this.textBox_soluong.Location = new System.Drawing.Point(104, 62);
            this.textBox_soluong.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_soluong.Name = "textBox_soluong";
            this.textBox_soluong.Size = new System.Drawing.Size(169, 22);
            this.textBox_soluong.TabIndex = 11;
            this.textBox_soluong.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_soluong_KeyDown);
            this.textBox_soluong.Leave += new System.EventHandler(this.textBox_soluong_Leave);
            // 
            // comboBox_mahang
            // 
            this.comboBox_mahang.FormattingEnabled = true;
            this.comboBox_mahang.Location = new System.Drawing.Point(104, 30);
            this.comboBox_mahang.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_mahang.Name = "comboBox_mahang";
            this.comboBox_mahang.Size = new System.Drawing.Size(169, 24);
            this.comboBox_mahang.TabIndex = 11;
            this.comboBox_mahang.SelectedIndexChanged += new System.EventHandler(this.comboBox_mahang_SelectedIndexChanged);
            // 
            // dataGridView_hoadon
            // 
            this.dataGridView_hoadon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_hoadon.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView_hoadon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_hoadon.Location = new System.Drawing.Point(31, 98);
            this.dataGridView_hoadon.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_hoadon.Name = "dataGridView_hoadon";
            this.dataGridView_hoadon.RowHeadersWidth = 51;
            this.dataGridView_hoadon.Size = new System.Drawing.Size(967, 162);
            this.dataGridView_hoadon.TabIndex = 17;
            this.dataGridView_hoadon.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_hoadon_CellDoubleClick);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(640, 65);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 16);
            this.label15.TabIndex = 16;
            this.label15.Text = "Thành tiền:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(640, 33);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 16);
            this.label14.TabIndex = 15;
            this.label14.Text = "Đơn giá:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(285, 65);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 16);
            this.label13.TabIndex = 14;
            this.label13.Text = "Giảm giá %";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(285, 33);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 16);
            this.label12.TabIndex = 13;
            this.label12.Text = "Tên hàng:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 65);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 16);
            this.label11.TabIndex = 12;
            this.label11.Text = "Số lượng: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 33);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 16);
            this.label10.TabIndex = 11;
            this.label10.Text = "Mã hàng:";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label19.Location = new System.Drawing.Point(19, 630);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(81, 16);
            this.label19.TabIndex = 32;
            this.label19.Text = "Mã hóa đơn:";
            // 
            // comboBox_mahoadon
            // 
            this.comboBox_mahoadon.AccessibleDescription = "x";
            this.comboBox_mahoadon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBox_mahoadon.FormattingEnabled = true;
            this.comboBox_mahoadon.Location = new System.Drawing.Point(127, 626);
            this.comboBox_mahoadon.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_mahoadon.Name = "comboBox_mahoadon";
            this.comboBox_mahoadon.Size = new System.Drawing.Size(169, 24);
            this.comboBox_mahoadon.TabIndex = 32;
            // 
            // button_timkiem
            // 
            this.button_timkiem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button_timkiem.Location = new System.Drawing.Point(317, 626);
            this.button_timkiem.Margin = new System.Windows.Forms.Padding(4);
            this.button_timkiem.Name = "button_timkiem";
            this.button_timkiem.Size = new System.Drawing.Size(133, 28);
            this.button_timkiem.TabIndex = 32;
            this.button_timkiem.Text = "Tìm kiếm";
            this.button_timkiem.UseVisualStyleBackColor = true;
            this.button_timkiem.Click += new System.EventHandler(this.button_timkiem_Click);
            // 
            // FormHoaDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1067, 670);
            this.Controls.Add(this.button_timkiem);
            this.Controls.Add(this.comboBox_mahoadon);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormHoaDon";
            this.Text = "FormHoaDon";
            this.Load += new System.EventHandler(this.FormHoaDon_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hoadon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_makhachhang;
        private System.Windows.Forms.TextBox textBox_dienthoai;
        private System.Windows.Forms.TextBox textBox_diachi;
        private System.Windows.Forms.TextBox textBox_tenkhachhang;
        private System.Windows.Forms.TextBox textBox_tennhanvien;
        private System.Windows.Forms.TextBox textBox_mahoadon;
        private System.Windows.Forms.ComboBox comboBox_manhanvien;
        private System.Windows.Forms.DateTimePicker dateTimePicker_ngayban;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView_hoadon;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox_thanhtien;
        private System.Windows.Forms.TextBox textBox_dongia;
        private System.Windows.Forms.TextBox textBox_giamgia;
        private System.Windows.Forms.TextBox textBox_tenhang;
        private System.Windows.Forms.TextBox textBox_soluong;
        private System.Windows.Forms.ComboBox comboBox_mahang;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox_mahoadon;
        private System.Windows.Forms.Button button_timkiem;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_themhoadon;
        private System.Windows.Forms.Button button_luu;
        private System.Windows.Forms.Button button_huyhoadon;
        private System.Windows.Forms.Button button_inhoadon;
        private System.Windows.Forms.Button button_dong;
        private System.Windows.Forms.TextBox textBox_tongtien;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label_tiendangchu;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button_khachhang;
    }
}