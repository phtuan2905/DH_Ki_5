﻿namespace LTTQ_C6_BT6_5
{
    partial class FormHangHoa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_danhmuchanghoa = new System.Windows.Forms.Label();
            this.label_mahang = new System.Windows.Forms.Label();
            this.textBox_mahang = new System.Windows.Forms.TextBox();
            this.label_tenhang = new System.Windows.Forms.Label();
            this.textBox_tenhang = new System.Windows.Forms.TextBox();
            this.label_chatlieu = new System.Windows.Forms.Label();
            this.comboBox_chatlieu = new System.Windows.Forms.ComboBox();
            this.textBox_soluong = new System.Windows.Forms.TextBox();
            this.label_soluong = new System.Windows.Forms.Label();
            this.textBox_dongianhap = new System.Windows.Forms.TextBox();
            this.label_dongianhap = new System.Windows.Forms.Label();
            this.textBox_dongiaban = new System.Windows.Forms.TextBox();
            this.label_dongiaban = new System.Windows.Forms.Label();
            this.pictureBox_anh = new System.Windows.Forms.PictureBox();
            this.label_ghichu = new System.Windows.Forms.Label();
            this.textBox_ghichu = new System.Windows.Forms.TextBox();
            this.button_anh = new System.Windows.Forms.Button();
            this.button_timkiem = new System.Windows.Forms.Button();
            this.button_xuatraexcel = new System.Windows.Forms.Button();
            this.dataGridView_hanghoa = new System.Windows.Forms.DataGridView();
            this.button_themmoi = new System.Windows.Forms.Button();
            this.button_luu = new System.Windows.Forms.Button();
            this.button_sua = new System.Windows.Forms.Button();
            this.button_xoa = new System.Windows.Forms.Button();
            this.button_boqua = new System.Windows.Forms.Button();
            this.button_thoat = new System.Windows.Forms.Button();
            this.button_chatlieu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_anh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hanghoa)).BeginInit();
            this.SuspendLayout();
            // 
            // label_danhmuchanghoa
            // 
            this.label_danhmuchanghoa.AutoSize = true;
            this.label_danhmuchanghoa.Font = new System.Drawing.Font("Lucida Handwriting", 21F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_danhmuchanghoa.ForeColor = System.Drawing.Color.IndianRed;
            this.label_danhmuchanghoa.Location = new System.Drawing.Point(288, 27);
            this.label_danhmuchanghoa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_danhmuchanghoa.Name = "label_danhmuchanghoa";
            this.label_danhmuchanghoa.Size = new System.Drawing.Size(470, 45);
            this.label_danhmuchanghoa.TabIndex = 0;
            this.label_danhmuchanghoa.Text = "DANH MỤC HÀNG HÓA";
            // 
            // label_mahang
            // 
            this.label_mahang.AutoSize = true;
            this.label_mahang.Location = new System.Drawing.Point(45, 95);
            this.label_mahang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_mahang.Name = "label_mahang";
            this.label_mahang.Size = new System.Drawing.Size(62, 16);
            this.label_mahang.TabIndex = 1;
            this.label_mahang.Text = "Mã hàng:";
            // 
            // textBox_mahang
            // 
            this.textBox_mahang.Location = new System.Drawing.Point(205, 95);
            this.textBox_mahang.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_mahang.Name = "textBox_mahang";
            this.textBox_mahang.Size = new System.Drawing.Size(407, 22);
            this.textBox_mahang.TabIndex = 2;
            // 
            // label_tenhang
            // 
            this.label_tenhang.AutoSize = true;
            this.label_tenhang.Location = new System.Drawing.Point(45, 148);
            this.label_tenhang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_tenhang.Name = "label_tenhang";
            this.label_tenhang.Size = new System.Drawing.Size(67, 16);
            this.label_tenhang.TabIndex = 3;
            this.label_tenhang.Text = "Tên hàng:";
            // 
            // textBox_tenhang
            // 
            this.textBox_tenhang.Location = new System.Drawing.Point(205, 148);
            this.textBox_tenhang.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_tenhang.Name = "textBox_tenhang";
            this.textBox_tenhang.Size = new System.Drawing.Size(407, 22);
            this.textBox_tenhang.TabIndex = 4;
            // 
            // label_chatlieu
            // 
            this.label_chatlieu.AutoSize = true;
            this.label_chatlieu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label_chatlieu.Location = new System.Drawing.Point(45, 199);
            this.label_chatlieu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_chatlieu.Name = "label_chatlieu";
            this.label_chatlieu.Size = new System.Drawing.Size(58, 16);
            this.label_chatlieu.TabIndex = 5;
            this.label_chatlieu.Text = "Chất liệu";
            // 
            // comboBox_chatlieu
            // 
            this.comboBox_chatlieu.FormattingEnabled = true;
            this.comboBox_chatlieu.Location = new System.Drawing.Point(205, 196);
            this.comboBox_chatlieu.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_chatlieu.Name = "comboBox_chatlieu";
            this.comboBox_chatlieu.Size = new System.Drawing.Size(233, 24);
            this.comboBox_chatlieu.TabIndex = 6;
            // 
            // textBox_soluong
            // 
            this.textBox_soluong.Location = new System.Drawing.Point(205, 245);
            this.textBox_soluong.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_soluong.Name = "textBox_soluong";
            this.textBox_soluong.Size = new System.Drawing.Size(407, 22);
            this.textBox_soluong.TabIndex = 8;
            // 
            // label_soluong
            // 
            this.label_soluong.AutoSize = true;
            this.label_soluong.Location = new System.Drawing.Point(45, 245);
            this.label_soluong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_soluong.Name = "label_soluong";
            this.label_soluong.Size = new System.Drawing.Size(63, 16);
            this.label_soluong.TabIndex = 7;
            this.label_soluong.Text = "Số lượng:";
            // 
            // textBox_dongianhap
            // 
            this.textBox_dongianhap.Location = new System.Drawing.Point(205, 295);
            this.textBox_dongianhap.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_dongianhap.Name = "textBox_dongianhap";
            this.textBox_dongianhap.Size = new System.Drawing.Size(407, 22);
            this.textBox_dongianhap.TabIndex = 10;
            // 
            // label_dongianhap
            // 
            this.label_dongianhap.AutoSize = true;
            this.label_dongianhap.Location = new System.Drawing.Point(45, 295);
            this.label_dongianhap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_dongianhap.Name = "label_dongianhap";
            this.label_dongianhap.Size = new System.Drawing.Size(89, 16);
            this.label_dongianhap.TabIndex = 9;
            this.label_dongianhap.Text = "Đơn giá nhập:";
            // 
            // textBox_dongiaban
            // 
            this.textBox_dongiaban.Location = new System.Drawing.Point(205, 348);
            this.textBox_dongiaban.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_dongiaban.Name = "textBox_dongiaban";
            this.textBox_dongiaban.Size = new System.Drawing.Size(407, 22);
            this.textBox_dongiaban.TabIndex = 12;
            // 
            // label_dongiaban
            // 
            this.label_dongiaban.AutoSize = true;
            this.label_dongiaban.Location = new System.Drawing.Point(45, 348);
            this.label_dongiaban.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_dongiaban.Name = "label_dongiaban";
            this.label_dongiaban.Size = new System.Drawing.Size(82, 16);
            this.label_dongiaban.TabIndex = 11;
            this.label_dongiaban.Text = "Đơn giá bán:";
            // 
            // pictureBox_anh
            // 
            this.pictureBox_anh.Location = new System.Drawing.Point(837, 99);
            this.pictureBox_anh.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox_anh.Name = "pictureBox_anh";
            this.pictureBox_anh.Size = new System.Drawing.Size(191, 191);
            this.pictureBox_anh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_anh.TabIndex = 13;
            this.pictureBox_anh.TabStop = false;
            // 
            // label_ghichu
            // 
            this.label_ghichu.AutoSize = true;
            this.label_ghichu.Location = new System.Drawing.Point(746, 301);
            this.label_ghichu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_ghichu.Name = "label_ghichu";
            this.label_ghichu.Size = new System.Drawing.Size(54, 16);
            this.label_ghichu.TabIndex = 14;
            this.label_ghichu.Text = "Ghi chú:";
            // 
            // textBox_ghichu
            // 
            this.textBox_ghichu.Location = new System.Drawing.Point(824, 298);
            this.textBox_ghichu.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_ghichu.MaxLength = 1000;
            this.textBox_ghichu.Multiline = true;
            this.textBox_ghichu.Name = "textBox_ghichu";
            this.textBox_ghichu.Size = new System.Drawing.Size(215, 73);
            this.textBox_ghichu.TabIndex = 15;
            // 
            // button_anh
            // 
            this.button_anh.Location = new System.Drawing.Point(716, 94);
            this.button_anh.Margin = new System.Windows.Forms.Padding(4);
            this.button_anh.Name = "button_anh";
            this.button_anh.Size = new System.Drawing.Size(100, 43);
            this.button_anh.TabIndex = 16;
            this.button_anh.Text = "Ảnh";
            this.button_anh.UseVisualStyleBackColor = true;
            this.button_anh.Click += new System.EventHandler(this.button_anh_Click);
            // 
            // button_timkiem
            // 
            this.button_timkiem.Location = new System.Drawing.Point(49, 393);
            this.button_timkiem.Margin = new System.Windows.Forms.Padding(4);
            this.button_timkiem.Name = "button_timkiem";
            this.button_timkiem.Size = new System.Drawing.Size(127, 43);
            this.button_timkiem.TabIndex = 17;
            this.button_timkiem.Text = "Tìm kiếm";
            this.button_timkiem.UseVisualStyleBackColor = true;
            // 
            // button_xuatraexcel
            // 
            this.button_xuatraexcel.Location = new System.Drawing.Point(205, 393);
            this.button_xuatraexcel.Margin = new System.Windows.Forms.Padding(4);
            this.button_xuatraexcel.Name = "button_xuatraexcel";
            this.button_xuatraexcel.Size = new System.Drawing.Size(127, 43);
            this.button_xuatraexcel.TabIndex = 18;
            this.button_xuatraexcel.Text = "Xuất ra Excel";
            this.button_xuatraexcel.UseVisualStyleBackColor = true;
            // 
            // dataGridView_hanghoa
            // 
            this.dataGridView_hanghoa.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dataGridView_hanghoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_hanghoa.GridColor = System.Drawing.SystemColors.Window;
            this.dataGridView_hanghoa.Location = new System.Drawing.Point(40, 443);
            this.dataGridView_hanghoa.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_hanghoa.Name = "dataGridView_hanghoa";
            this.dataGridView_hanghoa.RowHeadersWidth = 51;
            this.dataGridView_hanghoa.Size = new System.Drawing.Size(1000, 185);
            this.dataGridView_hanghoa.TabIndex = 19;
            this.dataGridView_hanghoa.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_hanghoa_CellClick);
            // 
            // button_themmoi
            // 
            this.button_themmoi.Location = new System.Drawing.Point(49, 666);
            this.button_themmoi.Margin = new System.Windows.Forms.Padding(4);
            this.button_themmoi.Name = "button_themmoi";
            this.button_themmoi.Size = new System.Drawing.Size(127, 43);
            this.button_themmoi.TabIndex = 20;
            this.button_themmoi.Text = "Thêm mới";
            this.button_themmoi.UseVisualStyleBackColor = true;
            this.button_themmoi.Click += new System.EventHandler(this.button_themmoi_Click);
            // 
            // button_luu
            // 
            this.button_luu.Location = new System.Drawing.Point(221, 666);
            this.button_luu.Margin = new System.Windows.Forms.Padding(4);
            this.button_luu.Name = "button_luu";
            this.button_luu.Size = new System.Drawing.Size(127, 43);
            this.button_luu.TabIndex = 21;
            this.button_luu.Text = "Lưu";
            this.button_luu.UseVisualStyleBackColor = true;
            this.button_luu.Click += new System.EventHandler(this.button_luu_Click);
            // 
            // button_sua
            // 
            this.button_sua.Location = new System.Drawing.Point(375, 666);
            this.button_sua.Margin = new System.Windows.Forms.Padding(4);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(127, 43);
            this.button_sua.TabIndex = 22;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = true;
            this.button_sua.Click += new System.EventHandler(this.button_sua_Click);
            // 
            // button_xoa
            // 
            this.button_xoa.Location = new System.Drawing.Point(543, 666);
            this.button_xoa.Margin = new System.Windows.Forms.Padding(4);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(127, 43);
            this.button_xoa.TabIndex = 23;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = true;
            this.button_xoa.Click += new System.EventHandler(this.button_xoa_Click);
            // 
            // button_boqua
            // 
            this.button_boqua.Location = new System.Drawing.Point(716, 666);
            this.button_boqua.Margin = new System.Windows.Forms.Padding(4);
            this.button_boqua.Name = "button_boqua";
            this.button_boqua.Size = new System.Drawing.Size(127, 43);
            this.button_boqua.TabIndex = 24;
            this.button_boqua.Text = "Bỏ qua";
            this.button_boqua.UseVisualStyleBackColor = true;
            this.button_boqua.Click += new System.EventHandler(this.button_boqua_Click);
            // 
            // button_thoat
            // 
            this.button_thoat.Location = new System.Drawing.Point(889, 666);
            this.button_thoat.Margin = new System.Windows.Forms.Padding(4);
            this.button_thoat.Name = "button_thoat";
            this.button_thoat.Size = new System.Drawing.Size(127, 43);
            this.button_thoat.TabIndex = 25;
            this.button_thoat.Text = "Thoát";
            this.button_thoat.UseVisualStyleBackColor = true;
            this.button_thoat.Click += new System.EventHandler(this.button_thoat_Click);
            // 
            // button_chatlieu
            // 
            this.button_chatlieu.Location = new System.Drawing.Point(487, 186);
            this.button_chatlieu.Margin = new System.Windows.Forms.Padding(4);
            this.button_chatlieu.Name = "button_chatlieu";
            this.button_chatlieu.Size = new System.Drawing.Size(127, 43);
            this.button_chatlieu.TabIndex = 26;
            this.button_chatlieu.Text = "Chất liệu";
            this.button_chatlieu.UseVisualStyleBackColor = true;
            this.button_chatlieu.Click += new System.EventHandler(this.button_chatlieu_Click);
            // 
            // FormHangHoa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1077, 766);
            this.Controls.Add(this.button_chatlieu);
            this.Controls.Add(this.button_thoat);
            this.Controls.Add(this.button_boqua);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_luu);
            this.Controls.Add(this.button_themmoi);
            this.Controls.Add(this.dataGridView_hanghoa);
            this.Controls.Add(this.button_xuatraexcel);
            this.Controls.Add(this.button_timkiem);
            this.Controls.Add(this.button_anh);
            this.Controls.Add(this.textBox_ghichu);
            this.Controls.Add(this.label_ghichu);
            this.Controls.Add(this.pictureBox_anh);
            this.Controls.Add(this.textBox_dongiaban);
            this.Controls.Add(this.label_dongiaban);
            this.Controls.Add(this.textBox_dongianhap);
            this.Controls.Add(this.label_dongianhap);
            this.Controls.Add(this.textBox_soluong);
            this.Controls.Add(this.label_soluong);
            this.Controls.Add(this.comboBox_chatlieu);
            this.Controls.Add(this.label_chatlieu);
            this.Controls.Add(this.textBox_tenhang);
            this.Controls.Add(this.label_tenhang);
            this.Controls.Add(this.textBox_mahang);
            this.Controls.Add(this.label_mahang);
            this.Controls.Add(this.label_danhmuchanghoa);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormHangHoa";
            this.Text = "Form Hang Hoa";
            this.Load += new System.EventHandler(this.FormHangHoa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_anh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hanghoa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_danhmuchanghoa;
        private System.Windows.Forms.Label label_mahang;
        private System.Windows.Forms.TextBox textBox_mahang;
        private System.Windows.Forms.Label label_tenhang;
        private System.Windows.Forms.TextBox textBox_tenhang;
        private System.Windows.Forms.Label label_chatlieu;
        private System.Windows.Forms.ComboBox comboBox_chatlieu;
        private System.Windows.Forms.TextBox textBox_soluong;
        private System.Windows.Forms.Label label_soluong;
        private System.Windows.Forms.TextBox textBox_dongianhap;
        private System.Windows.Forms.Label label_dongianhap;
        private System.Windows.Forms.TextBox textBox_dongiaban;
        private System.Windows.Forms.Label label_dongiaban;
        private System.Windows.Forms.PictureBox pictureBox_anh;
        private System.Windows.Forms.Label label_ghichu;
        private System.Windows.Forms.TextBox textBox_ghichu;
        private System.Windows.Forms.Button button_anh;
        private System.Windows.Forms.Button button_timkiem;
        private System.Windows.Forms.Button button_xuatraexcel;
        private System.Windows.Forms.DataGridView dataGridView_hanghoa;
        private System.Windows.Forms.Button button_themmoi;
        private System.Windows.Forms.Button button_luu;
        private System.Windows.Forms.Button button_sua;
        private System.Windows.Forms.Button button_xoa;
        private System.Windows.Forms.Button button_boqua;
        private System.Windows.Forms.Button button_thoat;
        private System.Windows.Forms.Button button_chatlieu;
    }
}

