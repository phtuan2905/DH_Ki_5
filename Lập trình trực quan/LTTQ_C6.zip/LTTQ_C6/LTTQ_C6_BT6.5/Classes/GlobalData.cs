﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LTTQ_C6_BT6_5.Classes
{
    internal static class GlobalData
    {
        public static string manv = "";
    }
}
